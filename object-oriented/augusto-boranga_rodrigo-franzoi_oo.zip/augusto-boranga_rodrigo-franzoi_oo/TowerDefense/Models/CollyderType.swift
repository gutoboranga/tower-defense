//
//  CollyderType.swift
//  TowerDefense
//
//  Created by Rodrigo Franzoi Scroferneker on 28/11/17.
//  Copyright © 2017 gatosDeSchnorrdinger. All rights reserved.
//

struct ColliderType {
    static var Enemy    : UInt32 = 1
    static var Obstacle : UInt32 = 2
}
